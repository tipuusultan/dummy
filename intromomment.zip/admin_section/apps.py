from django.apps import AppConfig


class AdminSectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'admin_section'
